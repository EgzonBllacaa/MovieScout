import { useState } from 'react';

// Components
import Header from './Components/Header/Header';
import MovieHero from './Components/MovieHero/MovieHero'

// Libraries
import axios from 'axios';
// CSS
import './App.css';

const apiKey = '6d516ab1';

const App = () => {
  const [inputValue, setInputValue] = useState('');
  const [showError, setError] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [movieData, setMovieData] = useState(null);

  const inputChange = (event) => {
    setInputValue(event.target.value);
  };

  const onSearchHandler = async (event) => {
    event.preventDefault();
    
    if (inputValue.trim() === '') {
      setError(true);
      setErrorMessage('Please enter a movie title');
      return;
    } else {
      setError(false);
      setErrorMessage('');
      setIsLoading(true);
      setMovieData(null);

      try {
        const response = await axios.get(`http://www.omdbapi.com/?t=${inputValue}&apikey=${apiKey}`);

        if (response.data.Response === 'True') {
          const obj = {
            poster: response.data.Poster,
            title: response.data.Title,
            type: response.data.Type,
            actors: response.data.Actors,
            awards: response.data.Awards,
            genre: response.data.Genre,
            year: response.data.Year,
            plot: response.data.Plot,
            boxOffice: response.data.BoxOffice,
          };

          setTimeout(() => {
            setIsLoading(false);
            setMovieData(obj);
            setInputValue('');
          }, 3000);
        } else {
          setIsLoading(false);
          setMovieData(null);
          setErrorMessage('Movie not found.');
          setError(true);
        }
      } catch (error) {
        setIsLoading(false);
        setError(true);
        setErrorMessage(error.message || 'An error occurred while fetching the movie data.');
        setInputValue('');
      }
    }
  };

  return (
    <>
      <Header />
      <div className="search-form">
        <form id="searchForm" onSubmit={onSearchHandler}>
          <input
            value={inputValue}
            type="text"
            name="search"
            className="input"
            placeholder="Search any movie"
            onChange={inputChange}
          />
          <input type="submit" className="btn" value="Search" />
          {showError && (
            <p style={{ color: 'red', margin: '30px 0' }}>{errorMessage}</p>
          )}
        </form>
      </div>
      <div className="movie-container">
        {isLoading ? (
          <svg className="spinner" viewBox="0 0 50 50">
            <circle
              className="path"
              cx="25"
              cy="25"
              r="20"
              fill="none"
              strokeWidth="5"
            ></circle>
          </svg>
        ) : movieData ? (
          <div className="movie">
            <MovieHero
              poster={movieData.poster}
              title={movieData.title}
              type={movieData.type}
              genre={movieData.genre}
              awards={movieData.awards}
              year={movieData.year}
              plot={movieData.plot}
              boxOffice={movieData.boxOffice}
              actors={movieData.actors}
            />
          </div>
        ) : null}
      </div>
    </>
  );
};

export default App;
