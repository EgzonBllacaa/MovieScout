import Logo from '../../assets/Logo.png'
import './Header.css'
function Header() {
  return (
    <div className='header'>
      <img src={Logo} alt="" />
      <h1>Movie Finder</h1>
    </div>
  )
}

export default Header