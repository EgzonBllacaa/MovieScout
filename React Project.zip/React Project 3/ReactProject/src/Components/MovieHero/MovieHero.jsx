
import './MovieHero.css'
import PropTypes  from "prop-types"
const MovieHero = (props) => {
  
  const {poster,title, type, actors, awards, genre, year, plot, boxOffice} = props

  return (
    <>
      <div className="movie-hero">
        <div className="movie-info">
          <img src={poster} alt="" />
          <h2>{title}</h2>
          <h4>{type}  <br />Genre: {genre}</h4>
        </div>

          <div className="movie-details">
          <p>🏆 <b>Awards:</b> {awards} </p>
          <p>💰 <b>Box Office:</b> {boxOffice}</p>
          <hr />

          <p>📅 {type} was made in {year}</p>
          <p>{plot}</p>
          <p>🎭 <b>Main Actors:</b> {actors}</p>
          </div>
      </div>
    </>
  )
}
MovieHero.propTypes = {
  poster: PropTypes.string,
  title: PropTypes.string,
  type: PropTypes.string,
  actors: PropTypes.string,
  awards: PropTypes.string,
  genre: PropTypes.string,
  year: PropTypes.number,
  plot: PropTypes.string,
  boxOffice: PropTypes.number
}

export default MovieHero